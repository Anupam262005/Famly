// src/utils/notificationContext.jsx
// Global notification state: unread count badge, live toast popup, and cached list.
//
// Wire into main.jsx:
//   <SocketProvider><NotificationProvider>...</NotificationProvider></SocketProvider>
//
// Then in any component:
//   const { unreadCount, notifications, fetchNotifications } = useNotifications();

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
} from "react";
import { toast } from "react-toastify";
import api from "./axios";
import { useAuth } from "./authContext";

import { useSocket } from "./socketContext";

const NotificationContext = createContext(null);

export const NotificationProvider = ({ children }) => {
  const [unreadCount, setUnreadCount] = useState(0);
  const [notifications, setNotifications] = useState([]);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(false);

  // ✅ socket is now a real reactive value (not null) thanks to socketContext fix
  const { socket } = useSocket();

  const { auth } = useAuth();
  const isLoggedIn = !!auth?.user;

  // ── Fetch paginated notifications from REST ──────────────────────────────
  const fetchNotifications = useCallback(
    async (page = 1) => {
      if (!isLoggedIn) return;
      setLoading(true);
      try {
        const res = await api.get(`/notification/user?page=${page}`);
        const d = res.data.data;
        setNotifications(d.notifications);
        setTotalPages(d.totalPages);
        setUnreadCount(d.unreadCount ?? 0);
      } catch (err) {
        console.error("Failed to fetch notifications", err);
      } finally {
        setLoading(false);
      }
    },
    [isLoggedIn]
  );

  // ── Initial fetch on mount ────────────────────────────────────────────────
  useEffect(() => {
    fetchNotifications(1);
  }, [fetchNotifications]);

  // ── Socket listeners ─────────────────────────────────────────────────────
  // ✅ This effect now actually runs because socket is no longer permanently null
  useEffect(() => {
    if (!socket) return;

    console.log("📡 Registering notification socket listeners on", socket.id);

    // Real-time badge update
    const onUnreadCount = ({ count }) => setUnreadCount(count);

    // New notification arrives → prepend to list + show toast
    const onNewNotification = (notif) => {
      setNotifications((prev) => {
        // Avoid duplicates (e.g. if REST fetch races with socket push)
        if (prev.some((n) => n._id === notif._id)) return prev;
        return [notif, ...prev];
      });
      setUnreadCount((c) => c + 1);

      // Toast based on type
      if (notif.type === "join_request") {
        toast.info(
          `📬 ${notif.joinRequest?.requesterName} wants to join ${notif.joinRequest?.targetName}`,
          { autoClose: 8000 }
        );
      } else if (notif.type === "join_response") {
        const accepted = notif.joinRequest?.decision === "accepted";
        accepted
          ? toast.success(`✅ ${notif.title}`)
          : toast.error(`❌ ${notif.title}`);
      } else if (notif.type === "family_invitation") {
        toast.info(`👨‍👩‍👧 ${notif.title}`, { autoClose: 8000 });
      } else if (notif.type === "family_invitation_response") {
        const accepted = notif.familyInvitation?.decision === "accepted";
        accepted
          ? toast.success(`✅ ${notif.title}`)
          : toast.info(`ℹ️ ${notif.title}`);
      } else {
        toast.info(`🔔 ${notif.title}: ${notif.message}`, { autoClose: 5000 });
      }
    };

    // Owner responded to a join request — update the local notification card
    const onJoinRequestUpdated = ({ notifId, decision }) => {
      setNotifications((prev) =>
        prev.map((n) =>
          n._id === notifId
            ? { ...n, joinRequest: { ...n.joinRequest, decision }, status: "read" }
            : n
        )
      );
    };

    socket.on("unread_count", onUnreadCount);
    socket.on("new_notification", onNewNotification);
    socket.on("join_request_updated", onJoinRequestUpdated);

    // Re-fetch the notification list when we get a fresh socket connection
    // (covers the case where user was offline and missed notifications)
    const onConnect = () => {
      console.log("✅ Socket connected:", socket.id);
      fetchNotifications(1);
    };

    socket.on("connect", onConnect);

    return () => {
      socket.off("unread_count", onUnreadCount);
      socket.off("new_notification", onNewNotification);
      socket.off("join_request_updated", onJoinRequestUpdated);
      socket.off("connect", onConnect);
    };
  }, [socket, fetchNotifications]);

  // ── Mark one as read ──────────────────────────────────────────────────────
  const markAsRead = useCallback(async (notifId) => {
    try {
      await api.patch(`/notification/${notifId}/read`);
      setNotifications((prev) =>
        prev.map((n) => (n._id === notifId ? { ...n, status: "read" } : n))
      );
      setUnreadCount((c) => Math.max(0, c - 1));
    } catch (err) {
      console.error("markAsRead error", err);
    }
  }, []);

  // ── Mark all as read ──────────────────────────────────────────────────────
  const markAllAsRead = useCallback(async () => {
    try {
      await api.patch("/notification/read-all");
      setNotifications((prev) => prev.map((n) => ({ ...n, status: "read" })));
      setUnreadCount(0);
    } catch (err) {
      console.error("markAllAsRead error", err);
    }
  }, []);

  // ── Delete notification ───────────────────────────────────────────────────
  const deleteNotification = useCallback(async (notifId, groupNotificationId) => {
    try {
      await api.delete(`/notification/${notifId}`);
      if (groupNotificationId) {
        setNotifications((prev) =>
          prev.filter((n) => n.meta?.groupNotificationId !== groupNotificationId)
        );
      } else {
        setNotifications((prev) => prev.filter((n) => n._id !== notifId));
      }
    } catch (err) {
      console.error("deleteNotification error", err);
    }
  }, []);

  return (
    <NotificationContext.Provider
      value={{
        unreadCount,
        notifications,
        totalPages,
        loading,
        fetchNotifications,
        markAsRead,
        markAllAsRead,
        deleteNotification,
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => useContext(NotificationContext);
