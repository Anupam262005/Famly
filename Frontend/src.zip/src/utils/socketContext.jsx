// // src/utils/socketContext.jsx
// // Provides a Socket.io connection shared across the whole app.
// //
// // FIXES applied:
// //  1. Use useState (not useRef) so the context value is reactive — consumers
// //     get a non-null socket after it is created.
// //  2. Derive the socket root URL from VITE_SERVER by stripping "/api/v1"
// //     (Socket.io must connect to the server root, not an API sub-path).
// //  3. Listen for "storage" events so if axios silently refreshes the token and
// //     writes a new one to localStorage, the socket reconnects with the fresh token.
// //  4. Expose a `reconnect()` helper that axios.js can call after a token refresh
// //     so the socket immediately uses the new token.

// import { createContext, useContext, useEffect, useState, useCallback, useRef } from "react";
// import { io } from "socket.io-client";
// import { getAuthData } from "./auth.utils";

// const SocketContext = createContext(null);

// /** Derive root server URL from VITE_SERVER (strip "/api/v1" or any "/api/..." suffix) */
// const getSocketUrl = () => {
//   const server = import.meta.env.VITE_SERVER || "http://localhost:8000";
//   try {
//     const url = new URL(server);
//     return url.origin; // e.g. "http://localhost:8000"
//   } catch {
//     return server;
//   }
// };

// export const SocketProvider = ({ children }) => {
//   const [socket, setSocket] = useState(null);
//   const [connected, setConnected] = useState(false);
//   // Track current token so we can detect when it changes
//   const tokenRef = useRef(null);

//   const createSocket = useCallback(() => {
//     const auth = getAuthData();
//     const token = auth?.accessToken ?? null;

//     if (!token) {
//       // Not logged in — clean up
//       setSocket((prev) => {
//         if (prev) prev.disconnect();
//         return null;
//       });
//       setConnected(false);
//       tokenRef.current = null;
//       return;
//     }

//     // Skip reconnect if the token hasn't changed
//     if (token === tokenRef.current) return;
//     tokenRef.current = token;

//     const socketUrl = getSocketUrl();
//     console.log("🔌 Connecting Socket.io to:", socketUrl);

//     // Disconnect any existing socket first
//     setSocket((prev) => {
//       if (prev) {
//         prev.disconnect();
//       }
//       return null;
//     });

//     const s = io(socketUrl, {
//       auth: { token },
//       withCredentials: true,
//       reconnectionAttempts: 5,
//       reconnectionDelay: 2000,
//     });

//     setSocket(s);

//     s.on("connect", () => {
//       console.log("🟢 Socket connected:", s.id);
//       setConnected(true);
//     });

//     s.on("disconnect", () => {
//       console.log("🔴 Socket disconnected");
//       setConnected(false);
//     });

//     s.on("connect_error", (err) => {
//       console.error("❌ Socket error:", err.message);
//       // If auth failed, the token might be expired — clear ref so next call reconnects
//       if (err.message === "Invalid token" || err.message === "Authentication required") {
//         tokenRef.current = null;
//       }
//     });
//   }, []);

//   // Initial connection on mount
//   useEffect(() => {
//     createSocket();
//     // eslint-disable-next-line react-hooks/exhaustive-deps
//   }, []);

//   // Listen for localStorage changes (cross-tab support + token refresh detection)
//   useEffect(() => {
//     const handleStorage = (e) => {
//       if (e.key === "auth") {
//         console.log("🔄 Auth token changed in localStorage — reconnecting socket...");
//         createSocket();
//       }
//     };
//     window.addEventListener("storage", handleStorage);
//     return () => window.removeEventListener("storage", handleStorage);
//   }, [createSocket]);

//   // Cleanup on unmount
//   useEffect(() => {
//     return () => {
//       setSocket((prev) => {
//         if (prev) prev.disconnect();
//         return null;
//       });
//     };
//   }, []);

//   return (
//     <SocketContext.Provider value={{ socket, connected, reconnectSocket: createSocket }}>
//       {children}
//     </SocketContext.Provider>
//   );
// };

// export const useSocket = () => useContext(SocketContext);

// src/utils/socketContext.jsx

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  useRef,
} from "react";
import { io } from "socket.io-client";
import { useAuth } from "./authContext";

const SocketContext = createContext(null);

/** Derive root server URL from VITE_SERVER */
const getSocketUrl = () => {
  const server = import.meta.env.VITE_SERVER || "http://localhost:8000";

  try {
    const url = new URL(server);
    return url.origin; // e.g. http://localhost:8000
  } catch {
    return server;
  }
};

export const SocketProvider = ({ children }) => {
  const { auth } = useAuth();

  const [socket, setSocket] = useState(null);
  const [connected, setConnected] = useState(false);

  // Keep references so callbacks don't suffer from stale closures
  const socketRef = useRef(null);
  const tokenRef = useRef(null);

  const createSocket = useCallback(() => {
    const token = auth?.accessToken ?? null;

    // User logged out
    if (!token) {
      if (socketRef.current) {
        socketRef.current.disconnect();
        socketRef.current = null;
      }

      setSocket(null);
      setConnected(false);
      tokenRef.current = null;
      return;
    }

    // Already connected with same token
    if (
      token === tokenRef.current &&
      socketRef.current &&
      socketRef.current.connected
    ) {
      return;
    }

    tokenRef.current = token;

    // Disconnect previous socket before creating a new one
    if (socketRef.current) {
      socketRef.current.disconnect();
      socketRef.current = null;
    }

    const socketUrl = getSocketUrl();
    console.log("🔌 Connecting Socket.io to:", socketUrl);

    const s = io(socketUrl, {
      auth: {
        token,
      },
      withCredentials: true,
      reconnection: true,
      reconnectionAttempts: 5,
      reconnectionDelay: 2000,
    });

    socketRef.current = s;
    setSocket(s);

    s.on("connect", () => {
      console.log("🟢 Socket connected:", s.id);
      setConnected(true);
    });

    s.on("disconnect", (reason) => {
      console.log("🔴 Socket disconnected:", reason);
      setConnected(false);
    });

    s.on("connect_error", (err) => {
      console.error("❌ Socket error:", err.message);

      // If authentication failed, allow a future reconnect
      if (
        err.message === "Invalid token" ||
        err.message === "Authentication required"
      ) {
        tokenRef.current = null;
      }
    });
  }, [auth?.accessToken]);

  // Connect/reconnect whenever auth token changes
  useEffect(() => {
    createSocket();
  }, [createSocket]);

  // Cross-tab + axios refresh-token support
  useEffect(() => {
    const handleStorage = (e) => {
      if (e.key === "auth") {
        console.log(
          "🔄 Auth changed in localStorage — reconnecting socket..."
        );
        createSocket();
      }
    };

    window.addEventListener("storage", handleStorage);

    return () => {
      window.removeEventListener("storage", handleStorage);
    };
  }, [createSocket]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (socketRef.current) {
        socketRef.current.disconnect();
        socketRef.current = null;
      }
    };
  }, []);

  return (
    <SocketContext.Provider
      value={{
        socket,
        connected,
        reconnectSocket: createSocket,
      }}
    >
      {children}
    </SocketContext.Provider>
  );
};

export const useSocket = () => {
  const context = useContext(SocketContext);

  if (!context) {
    throw new Error("useSocket must be used inside SocketProvider");
  }

  return context;
};