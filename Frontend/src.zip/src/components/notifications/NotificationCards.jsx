
// import { useState } from "react";
// import { Trash2, Clock, CheckCircle, XCircle, UserPlus, MessageSquare, Bell } from "lucide-react";
// import api from "../../utils/axios";
// import { toast } from "react-toastify";
// import { useNotifications } from "../../utils/notificationContext";

// export default function NotificationCard({ notification, auth }) {
//   const { deleteNotification } = useNotifications();
//   const userId = Number(auth?.user?.user_id);
//   const isSender = notification.meta?.fromUserId === userId;

//   const [joinDecision, setJoinDecision] = useState(
//     notification.joinRequest?.decision || "pending"
//   );
//   const [responding, setResponding] = useState(false);

//   // ── Date formatting ──────────────────────────────────────────────────────
//   const formattedDate = new Date(notification.createdAt).toLocaleString("en-US", {
//     month: "short", day: "numeric", year: "numeric",
//     hour: "2-digit", minute: "2-digit",
//   });

//   // ── Handle join request response (owner clicks Accept / Reject) ──────────
//   const handleJoinResponse = async (decision) => {
//     setResponding(true);
//     try {
//       await api.patch(`/notification/join-request/${notification._id}/respond`, { decision });
//       setJoinDecision(decision);
//       toast.success(decision === "accepted" ? "✅ Request accepted!" : "Request rejected");
//     } catch (err) {
//       toast.error(err.response?.data?.message || "Failed to respond");
//     } finally {
//       setResponding(false);
//     }
//   };

//   // ── Handle delete (only sender of a message can do bulk delete) ──────────
//   const handleDelete = async () => {
//     if (!window.confirm("Delete this notification?")) return;
//     await deleteNotification(notification._id, notification.meta?.groupNotificationId);
//   };

//   // ── Card colour by status ─────────────────────────────────────────────────
//   const borderColor =
//     notification.status === "unread" ? "border-indigo-400" : "border-gray-200";

//   // ── TYPE: join_request ────────────────────────────────────────────────────
//   if (notification.type === "join_request") {
//     const { requesterName, targetName, targetType } = notification.joinRequest || {};
//     return (
//       <div className={`bg-white rounded-2xl p-5 mb-4 shadow border-l-4 ${borderColor}`}>
//         <div className="flex items-center gap-2 mb-3">
//           <span className="p-1.5 bg-amber-100 rounded-full">
//             <UserPlus size={16} className="text-amber-600" />
//           </span>
//           <span className="text-xs font-bold uppercase tracking-wide text-amber-600">
//             Join Request · {targetType}
//           </span>
//         </div>

//         <h3 className="text-lg font-bold text-gray-900 mb-1">{notification.title}</h3>
//         <p className="text-gray-600 text-sm mb-4">{notification.message}</p>

//         {/* Action buttons — shown only if still pending */}
//         {joinDecision === "pending" ? (
//           <div className="flex gap-3">
//             <button
//               onClick={() => handleJoinResponse("accepted")}
//               disabled={responding}
//               className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-green-600 hover:bg-green-700 text-white text-sm font-semibold transition-colors disabled:opacity-50"
//             >
//               <CheckCircle size={15} />
//               Accept
//             </button>
//             <button
//               onClick={() => handleJoinResponse("rejected")}
//               disabled={responding}
//               className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-red-500 hover:bg-red-600 text-white text-sm font-semibold transition-colors disabled:opacity-50"
//             >
//               <XCircle size={15} />
//               Reject
//             </button>
//           </div>
//         ) : (
//           <div className={`flex items-center gap-1.5 text-sm font-medium ${joinDecision === "accepted" ? "text-green-600" : "text-red-500"
//             }`}>
//             {joinDecision === "accepted"
//               ? <><CheckCircle size={15} /> You accepted this request</>
//               : <><XCircle size={15} /> You rejected this request</>
//             }
//           </div>
//         )}

//         <p className="text-xs text-gray-400 mt-3 flex items-center gap-1">
//           <Clock size={11} /> {formattedDate}
//         </p>
//       </div>
//     );
//   }

//   // ── TYPE: join_response ───────────────────────────────────────────────────
//   if (notification.type === "join_response") {
//     const accepted = notification.joinRequest?.decision === "accepted";
//     return (
//       <div className={`bg-white rounded-2xl p-5 mb-4 shadow border-l-4 ${accepted ? "border-green-400" : "border-red-400"
//         }`}>
//         <div className="flex items-center gap-2 mb-3">
//           <span className={`p-1.5 rounded-full ${accepted ? "bg-green-100" : "bg-red-100"}`}>
//             {accepted
//               ? <CheckCircle size={16} className="text-green-600" />
//               : <XCircle size={16} className="text-red-500" />
//             }
//           </span>
//           <span className={`text-xs font-bold uppercase tracking-wide ${accepted ? "text-green-600" : "text-red-500"
//             }`}>
//             Request {accepted ? "Accepted" : "Rejected"}
//           </span>
//         </div>

//         <h3 className="text-lg font-bold text-gray-900 mb-1">{notification.title}</h3>
//         <p className="text-gray-600 text-sm">{notification.message}</p>

//         <p className="text-xs text-gray-400 mt-3 flex items-center gap-1">
//           <Clock size={11} /> {formattedDate}
//         </p>
//       </div>
//     );
//   }

//   // ── TYPE: message (and legacy types) ─────────────────────────────────────
//   const senderName = notification.senderName || notification.meta?.fromUserName || "System";
//   const audienceName = notification.meta?.audienceName;

//   return (
//     <div className={`bg-white rounded-2xl p-5 mb-4 shadow border-l-4 ${borderColor}`}>
//       <div className="flex items-center justify-between mb-3">
//         <div className="flex items-center gap-2">
//           <span className="p-1.5 bg-indigo-100 rounded-full">
//             <MessageSquare size={15} className="text-indigo-600" />
//           </span>
//           <span className="text-xs font-bold uppercase tracking-wide text-indigo-500">
//             Message
//             {audienceName && (
//               <span className="ml-1.5 font-normal text-gray-400 normal-case">
//                 → {audienceName}
//               </span>
//             )}
//           </span>
//         </div>

//         {/* Only the sender of a broadcast can delete it */}
//         {isSender && (
//           <button
//             onClick={handleDelete}
//             className="text-gray-300 hover:text-red-500 transition-colors p-1 rounded-full hover:bg-red-50"
//             title="Delete for everyone"
//           >
//             <Trash2 size={16} />
//           </button>
//         )}
//       </div>

//       <h3 className="text-base font-bold text-gray-900 mb-1">{notification.title}</h3>

//       <p className="text-sm text-gray-500 font-medium mb-0.5">{senderName}:</p>
//       <p className="text-gray-700 text-sm italic leading-relaxed">
//         "{notification.message}"
//       </p>

//       <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
//         <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${notification.status === "unread"
//           ? "bg-indigo-100 text-indigo-600"
//           : "bg-gray-100 text-gray-400"
//           }`}>
//           {notification.status}
//         </span>
//         <p className="text-xs text-gray-400 flex items-center gap-1">
//           <Clock size={11} /> {formattedDate}
//         </p>
//       </div>
//     </div>
//   );
// }

// src/components/notifications/NotificationCards.jsx
// Handles card types: message, join_request, join_response, family_invitation, family_invitation_response

import { useState } from "react";
import { Trash2, Clock, CheckCircle, XCircle, UserPlus, MessageSquare, Crown, Bell } from "lucide-react";
import api from "../../utils/axios";
import { toast } from "react-toastify";
import { useNotifications } from "../../utils/notificationContext";

export default function NotificationCard({ notification, auth }) {
  const { deleteNotification } = useNotifications();
  const userId = Number(auth?.user?.user_id);
  const isSender = notification.meta?.fromUserId === userId;

  const [decision, setDecision] = useState(
    notification.joinRequest?.decision ||
    notification.familyInvitation?.decision ||
    "pending"
  );
  const [responding, setResponding] = useState(false);

  const formattedDate = new Date(notification.createdAt).toLocaleString("en-US", {
    month: "short", day: "numeric", year: "numeric",
    hour: "2-digit", minute: "2-digit",
  });

  // ── Handle join request response (family admin accepts/rejects user's join request) ──
  const handleJoinResponse = async (dec) => {
    setResponding(true);
    try {
      await api.patch(`/notification/join-request/${notification._id}/respond`, { decision: dec });
      setDecision(dec);
      toast.success(dec === "accepted" ? "✅ User added to family!" : "Request rejected");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to respond");
    } finally {
      setResponding(false);
    }
  };

  // ── Handle family invitation response (invited user accepts/rejects admin's invitation) ──
  const handleInvitationResponse = async (dec) => {
    setResponding(true);
    try {
      await api.patch(`/family/invitation/${notification._id}/respond`, { decision: dec });
      setDecision(dec);
      toast.success(dec === "accepted" ? "✅ You've joined the family!" : "Invitation declined");
    } catch (err) {
      toast.error(err.response?.data?.message || "Failed to respond");
    } finally {
      setResponding(false);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("Delete this notification?")) return;
    await deleteNotification(notification._id, notification.meta?.groupNotificationId);
  };

  const borderColor = notification.status === "unread" ? "border-indigo-400" : "border-gray-200";
  const isPending = decision === "pending";
  const isAccepted = decision === "accepted";

  // ── TYPE: join_request (family admin sees this — user wants to join via code) ──
  if (notification.type === "join_request") {
    const { requesterName, targetName, targetType } = notification.joinRequest || {};
    return (
      <div className={`bg-white rounded-2xl p-5 mb-4 shadow-sm border border-gray-100 border-l-4 ${borderColor}`}>
        <div className="flex items-center gap-2 mb-3">
          <span className="p-1.5 bg-amber-100 rounded-full">
            <UserPlus size={15} className="text-amber-600" />
          </span>
          <span className="text-xs font-bold uppercase tracking-wide text-amber-600">
            Join Request · {targetType === "family" ? "Family" : "Group"}
          </span>
          {notification.status === "unread" && (
            <span className="ml-auto w-2 h-2 rounded-full bg-indigo-500" />
          )}
        </div>

        <h3 className="text-base font-bold text-gray-900 mb-1">{notification.title}</h3>
        <p className="text-gray-600 text-sm mb-4">{notification.message}</p>

        {isPending ? (
          <div className="flex gap-2">
            <button
              onClick={() => handleJoinResponse("accepted")}
              disabled={responding}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-green-600 hover:bg-green-700 text-white text-sm font-semibold transition-colors disabled:opacity-50"
            >
              <CheckCircle size={15} /> Accept
            </button>
            <button
              onClick={() => handleJoinResponse("rejected")}
              disabled={responding}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white text-sm font-semibold transition-colors disabled:opacity-50"
            >
              <XCircle size={15} /> Reject
            </button>
          </div>
        ) : (
          <div className={`flex items-center gap-1.5 text-sm font-semibold ${isAccepted ? "text-green-600" : "text-red-500"}`}>
            {isAccepted ? <CheckCircle size={15} /> : <XCircle size={15} />}
            {isAccepted ? "You accepted this request" : "You rejected this request"}
          </div>
        )}

        <p className="text-xs text-gray-400 mt-3 flex items-center gap-1">
          <Clock size={11} /> {formattedDate}
        </p>
      </div>
    );
  }

  // ── TYPE: join_response (user sees result of their join request via code) ──
  if (notification.type === "join_response") {
    const accepted = notification.joinRequest?.decision === "accepted";
    return (
      <div className={`bg-white rounded-2xl p-5 mb-4 shadow-sm border border-gray-100 border-l-4 ${accepted ? "border-green-400" : "border-red-400"}`}>
        <div className="flex items-center gap-2 mb-3">
          <span className={`p-1.5 rounded-full ${accepted ? "bg-green-100" : "bg-red-100"}`}>
            {accepted ? <CheckCircle size={15} className="text-green-600" /> : <XCircle size={15} className="text-red-500" />}
          </span>
          <span className={`text-xs font-bold uppercase tracking-wide ${accepted ? "text-green-600" : "text-red-500"}`}>
            {accepted ? "Request Accepted" : "Request Declined"}
          </span>
        </div>
        <h3 className="text-base font-bold text-gray-900 mb-1">{notification.title}</h3>
        <p className="text-gray-600 text-sm">{notification.message}</p>
        <p className="text-xs text-gray-400 mt-3 flex items-center gap-1">
          <Clock size={11} /> {formattedDate}
        </p>
      </div>
    );
  }

  // ── TYPE: family_invitation (user receives this — admin invited them to join) ──
  if (notification.type === "family_invitation") {
    const { invitedByName, familyName, role } = notification.familyInvitation || {};
    const isRootRole = role === "admin";
    return (
      <div className={`bg-white rounded-2xl p-5 mb-4 shadow-sm border border-gray-100 border-l-4 ${borderColor}`}>
        <div className="flex items-center gap-2 mb-3">
          <span className={`p-1.5 rounded-full ${isRootRole ? "bg-amber-100" : "bg-purple-100"}`}>
            {isRootRole
              ? <Crown size={15} className="text-amber-600" />
              : <UserPlus size={15} className="text-purple-600" />
            }
          </span>
          <span className={`text-xs font-bold uppercase tracking-wide ${isRootRole ? "text-amber-600" : "text-purple-600"}`}>
            {isRootRole ? "Root Member Invitation" : "Family Invitation"}
          </span>
          {notification.status === "unread" && (
            <span className="ml-auto w-2 h-2 rounded-full bg-indigo-500" />
          )}
        </div>

        <h3 className="text-base font-bold text-gray-900 mb-1">{notification.title}</h3>
        <p className="text-gray-600 text-sm mb-4">{notification.message}</p>

        {isPending ? (
          <div className="flex gap-2">
            <button
              onClick={() => handleInvitationResponse("accepted")}
              disabled={responding}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-green-600 hover:bg-green-700 text-white text-sm font-semibold transition-colors disabled:opacity-50"
            >
              <CheckCircle size={15} /> Accept
            </button>
            <button
              onClick={() => handleInvitationResponse("rejected")}
              disabled={responding}
              className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-xl bg-red-500 hover:bg-red-600 text-white text-sm font-semibold transition-colors disabled:opacity-50"
            >
              <XCircle size={15} /> Decline
            </button>
          </div>
        ) : (
          <div className={`flex items-center gap-1.5 text-sm font-semibold ${isAccepted ? "text-green-600" : "text-red-500"}`}>
            {isAccepted ? <CheckCircle size={15} /> : <XCircle size={15} />}
            {isAccepted ? "You accepted — welcome to the family!" : "You declined this invitation"}
          </div>
        )}

        <p className="text-xs text-gray-400 mt-3 flex items-center gap-1">
          <Clock size={11} /> {formattedDate}
        </p>
      </div>
    );
  }

  // ── TYPE: family_invitation_response (admin sees whether user accepted/declined) ──
  if (notification.type === "family_invitation_response") {
    const accepted = notification.familyInvitation?.decision === "accepted";
    return (
      <div className={`bg-white rounded-2xl p-5 mb-4 shadow-sm border border-gray-100 border-l-4 ${accepted ? "border-green-400" : "border-red-400"}`}>
        <div className="flex items-center gap-2 mb-3">
          <span className={`p-1.5 rounded-full ${accepted ? "bg-green-100" : "bg-red-100"}`}>
            {accepted ? <CheckCircle size={15} className="text-green-600" /> : <XCircle size={15} className="text-red-500" />}
          </span>
          <span className={`text-xs font-bold uppercase tracking-wide ${accepted ? "text-green-600" : "text-red-500"}`}>
            Invitation {accepted ? "Accepted" : "Declined"}
          </span>
        </div>
        <h3 className="text-base font-bold text-gray-900 mb-1">{notification.title}</h3>
        <p className="text-gray-600 text-sm">{notification.message}</p>
        <p className="text-xs text-gray-400 mt-3 flex items-center gap-1">
          <Clock size={11} /> {formattedDate}
        </p>
      </div>
    );
  }

  // ── TYPE: message (and legacy types) ─────────────────────────────────────
  const senderName = notification.senderName || notification.meta?.fromUserName || "System";
  const audienceName = notification.meta?.audienceName;

  return (
    <div className={`bg-white rounded-2xl p-5 mb-4 shadow-sm border border-gray-100 border-l-4 ${borderColor}`}>
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <span className="p-1.5 bg-indigo-100 rounded-full">
            <MessageSquare size={15} className="text-indigo-600" />
          </span>
          <span className="text-xs font-bold uppercase tracking-wide text-indigo-500">
            Message
            {audienceName && (
              <span className="ml-1.5 font-normal text-gray-400 normal-case">→ {audienceName}</span>
            )}
          </span>
          {notification.status === "unread" && (
            <span className="ml-1 w-2 h-2 rounded-full bg-indigo-500" />
          )}
        </div>
        {isSender && (
          <button
            onClick={handleDelete}
            className="text-gray-300 hover:text-red-500 transition-colors p-1 rounded-full hover:bg-red-50"
            title="Delete for everyone"
          >
            <Trash2 size={15} />
          </button>
        )}
      </div>

      <h3 className="text-base font-bold text-gray-900 mb-1">{notification.title}</h3>
      <p className="text-sm text-gray-500 font-medium mb-0.5">{senderName}:</p>
      <p className="text-gray-700 text-sm italic leading-relaxed">"{notification.message}"</p>

      <div className="flex items-center justify-between mt-3 pt-3 border-t border-gray-100">
        <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${notification.status === "unread" ? "bg-indigo-100 text-indigo-600" : "bg-gray-100 text-gray-400"
          }`}>
          {notification.status}
        </span>
        <p className="text-xs text-gray-400 flex items-center gap-1">
          <Clock size={11} /> {formattedDate}
        </p>
      </div>
    </div>
  );
}
