

// import { useEffect, useState } from "react";
// import api from "../../utils/axios";
// import { getAuthData } from "../../utils/auth.utils";
// import NotificationCard from "../../components/notifications/NotificationCards.jsx";

// export default function NotificationsPage() {
//   const [notifications, setNotifications] = useState([]);
//   const [page, setPage] = useState(1);
//   const [totalPages, setTotalPages] = useState(1);
//   const [loading, setLoading] = useState(false);

//   const auth = getAuthData();
//   const userId = parseInt(auth?.user?.user_id);

//   const fetchNotifications = async (pageNumber = 1) => {
//     if (!userId) return;
//     setLoading(true);
//     try {
//       const res = await api.get(`/notification/user?page=${pageNumber}`);
//       const data = res.data.data;
//       setNotifications(data.notifications);
//       setPage(data.page);
//       setTotalPages(data.totalPages);
//     } catch (err) {
//       console.error("Failed to fetch notifications:", err);
//     } finally {
//       setLoading(false);
//     }
//   };

//   const handleDeleteNotification = (notifId) => {
//     setNotifications((prev) => prev.filter((n) => n._id !== notifId));
//   };

//   useEffect(() => {
//     fetchNotifications(page);
//   }, [page, userId]);

//   return (
//     <div className="max-w-3xl mx-auto mt-10 p-4">
//       {/* 🎨 Enhanced Header */}
//       <div className="text-center mb-8">
//         <h1 className="text-4xl font-extrabold text-indigo-700 mb-2 tracking-tight">
//           Notifications & Reminders
//         </h1>
//         <p className="text-lg font-semibold text-gray-600">
//           Stay connected with important family moments
//         </p>
//       </div>

//       {loading && <p className="text-gray-500 text-center">Loading notifications...</p>}

//       {!loading && notifications.length === 0 && (
//         <p className="text-gray-500 text-center">No notifications available.</p>
//       )}

//       {notifications.map((notif) => (
//         <NotificationCard
//           key={notif._id}
//           notification={notif}
//           onDelete={handleDeleteNotification}
//           auth={auth}
//         />
//       ))}

//       {totalPages > 1 && (
//         <div className="flex justify-between items-center mt-6">
//           <button
//             onClick={() => setPage((prev) => Math.max(prev - 1, 1))}
//             disabled={page === 1}
//             className="px-4 py-2 bg-gray-200 rounded disabled:opacity-50 hover:bg-gray-300 transition"
//           >
//             Prev
//           </button>
//           <span className="font-medium text-gray-700">Page {page} of {totalPages}</span>
//           <button
//             onClick={() => setPage((prev) => Math.min(prev + 1, totalPages))}
//             disabled={page === totalPages}
//             className="px-4 py-2 bg-gray-200 rounded disabled:opacity-50 hover:bg-gray-300 transition"
//           >
//             Next
//           </button>
//         </div>
//       )}
//     </div>
//   );
// }
// src/pages/notifications/NotificationPage.jsx  ← REPLACE your existing file
//
// Now powered by NotificationContext (real-time via Socket.io)
// Shows messages + join requests + join responses

import { useState } from "react";
import { Bell, CheckCheck, RefreshCw } from "lucide-react";
import { getAuthData } from "../../utils/auth.utils";
import NotificationCard from "../../components/notifications/NotificationCards";
import { useNotifications } from "../../utils/notificationContext";

export default function NotificationsPage() {
  const auth = getAuthData();
  const {
    notifications,
    totalPages,
    loading,
    unreadCount,
    fetchNotifications,
    markAllAsRead,
  } = useNotifications();

  const [page, setPage] = useState(1);

  const handlePageChange = (newPage) => {
    setPage(newPage);
    fetchNotifications(newPage);
  };

  return (
    <div className="max-w-2xl mx-auto mt-8 px-4 pb-12">
      {/* ── Header ────────────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-3xl font-extrabold text-indigo-700 tracking-tight flex items-center gap-2">
            <Bell size={28} />
            Notifications
            {unreadCount > 0 && (
              <span className="ml-1 bg-red-500 text-white text-sm font-bold px-2 py-0.5 rounded-full">
                {unreadCount}
              </span>
            )}
          </h1>
          <p className="text-gray-500 text-sm mt-0.5">
            Messages, join requests, and updates — in real time
          </p>
        </div>

        <div className="flex gap-2">
          <button
            onClick={() => fetchNotifications(page)}
            className="p-2 rounded-lg border border-gray-200 hover:bg-gray-50 text-gray-500 transition-colors"
            title="Refresh"
          >
            <RefreshCw size={16} />
          </button>
          {unreadCount > 0 && (
            <button
              onClick={markAllAsRead}
              className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-indigo-50 hover:bg-indigo-100 text-indigo-600 text-sm font-medium transition-colors border border-indigo-200"
            >
              <CheckCheck size={15} />
              Mark all read
            </button>
          )}
        </div>
      </div>

      {/* ── List ──────────────────────────────────────────────────────────── */}
      {loading && (
        <div className="text-center py-12 text-gray-400">Loading notifications...</div>
      )}

      {!loading && notifications.length === 0 && (
        <div className="text-center py-16">
          <Bell size={40} className="text-gray-200 mx-auto mb-3" />
          <p className="text-gray-400 font-medium">No notifications yet</p>
          <p className="text-gray-300 text-sm mt-1">
            Messages and join requests will appear here in real time
          </p>
        </div>
      )}

      {notifications.map((notif) => (
        <NotificationCard key={notif._id} notification={notif} auth={auth} />
      ))}

      {/* ── Pagination ────────────────────────────────────────────────────── */}
      {totalPages > 1 && (
        <div className="flex justify-between items-center mt-6">
          <button
            onClick={() => handlePageChange(Math.max(page - 1, 1))}
            disabled={page === 1}
            className="px-4 py-2 bg-gray-100 rounded-lg disabled:opacity-40 hover:bg-gray-200 text-sm font-medium transition-colors"
          >
            ← Prev
          </button>
          <span className="text-sm text-gray-500">
            Page {page} of {totalPages}
          </span>
          <button
            onClick={() => handlePageChange(Math.min(page + 1, totalPages))}
            disabled={page === totalPages}
            className="px-4 py-2 bg-gray-100 rounded-lg disabled:opacity-40 hover:bg-gray-200 text-sm font-medium transition-colors"
          >
            Next →
          </button>
        </div>
      )}
    </div>
  );
}
